// ! IN CASE OPENAI goes down, then activate the fallback -> true
export const is_fallback = false;
